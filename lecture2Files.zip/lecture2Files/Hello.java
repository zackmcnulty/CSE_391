import java.util.*;

public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello hola bon jour ciao!");
		
		for (String a : args) {
			System.out.println(a);
		}
    }
}
